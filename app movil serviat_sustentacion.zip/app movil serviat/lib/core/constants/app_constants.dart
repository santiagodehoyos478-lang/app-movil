class AppConstants {
  static const String appName = 'AR SERVICIO';
  static const String userRole = 'admin';
  static const String apiBaseUrl = 'http://192.168.20.160:8080/api';
}
